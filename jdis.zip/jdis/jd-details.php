<?php
session_start();
require 'connections/dbcon.php';
include("function.php")
?>

<?php include('includes/header.php'); ?>
<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<div class="container-sm">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h3>Juvenile Delinquent Details
            <a href="admin-panel.php" class="btn btn-danger float-end">BACK</a>
          </h3>
        </div>
        <div class="card-body">
          <?php
          if (isset($_GET['id'])) {
            $id = mysqli_real_escape_string($con, $_GET['id']);
            $query = "SELECT * FROM jd_tbl WHERE id = '$id' ";
            $query_run = mysqli_query($con, $query);

            if (mysqli_num_rows($query_run) > 0) {
              $jd = mysqli_fetch_array($query_run);
          ?>
              <div class="ml-3">
                <label>ID</label>
                <p class="form-control">
                  <?= $jd['id']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Full Name</label>
                <p class="form-control">
                  <?= $jd['fullname']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Email</label>
                <p class="form-control">
                  <?= $jd['email']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Address</label>
                <p class="form-control">
                  <?= $jd['address']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Barangay</label>
                <p class="form-control">
                  <?= $jd['barangay_tbl_id']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Date of Birth</label>
                <p class="form-control">
                  <?= $jd['dob']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Age</label>
                <p class="form-control">
                  <?= $jd['age']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Gender</label>
                <p class="form-control">
                  <?= $jd['gender']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Phone</label>
                <p class="form-control">
                  <?= $jd['phone']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Offense</label>
                <p class="form-control">
                  <?= $jd['offense_id']; ?>
                </p>
              </div>
              <div class="ml-3">
                <label>Date of Offense</label>
                <p class="form-control">
                  <?= $jd['date_of_offense']; ?>
                </p>
              </div>
          <?php
            } else {
              echo "<h4>No such id found!</h4>";
            }
          }
          ?>

        </div>
      </div>
    </div>

  </div>
</div>

<?php include('includes/footer.php'); ?>