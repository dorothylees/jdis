<?php
session_start();
require 'connections/dbcon.php';
if (!isset($_SESSION['username']) && !isset($_SESSION['id'])) { ?>

  <?php include('includes/header.php'); ?>
  <div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
  <div class="container d-flex justify-content-center align-items-center mt-4">
    <form class="form-floating form-control" method="POST" action="admin-panel.php" style="width:450px ;">
      <div class="card">
        <img src="img/card.png" class="card-img-top">
        <h1 class="text-center p-3">Login</h1><br>
        <?php if (isset($_GET['error'])) { ?>
          <div class="alert alert-danger" role="alert">
            <?= $_GET['error'] ?>
          </div>
        <?php } ?>
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input type="text" class="form-control" name="username" id="username">
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
          <input type="password" class="form-control" name="password" id="password" required />
        </div>
        <div class="mb-1">
          <label class="form-label">Select user type</label>
        </div>
        <select class="form-select mb-3" name="role" id="" aria-label="Default select example">
          <option selected value="admin">Admin</option>
          <option value="user">User</option>
        </select>
        <button type="submit" name="login" value="Login" class="btn btn-primary">Login</button>
    </form>
  </div>

<?php } else {
  header("Location: user-panel.php");
} ?>
<?php include('includes/footer.php'); ?>