<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "jdis";

$con = mysqli_connect($hostname, $username, $password, $database);

if (!$con) {
 die('Connection Failed!');
}
