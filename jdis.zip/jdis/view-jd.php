<?php
session_start();
require 'connections/dbcon.php';
?>

<?php include('includes/header.php'); ?>

<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<?php include('message.php'); ?>
<div class="container-fluid mt-4">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4>Juvenile Delinquents
            <a href="admin-panel.pphp" class="btn btn-primary float-end">Add JD</a>
          </h4>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Barangay</th>
                <th>Date of Birth</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Phone</th>
                <th>Offense</th>
                <th>Date of Offense</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $query = "SELECT * FROM jd_tbl";
              $query_run = mysqli_query($con, $query);

              if (mysqli_num_rows($query_run) > 0) {
                foreach ($query_run as $jd) {
              ?>
                  <tr>
                    <td><?= $jd['id']; ?></td>
                    <td><?= $jd['fullname']; ?></td>
                    <td><?= $jd['email']; ?></td>
                    <td><?= $jd['address']; ?></td>
                    <td><?= $jd['barangay_tbl_id']; ?></td>
                    <td><?= $jd['dob']; ?></td>
                    <td><?= $jd['age']; ?></td>
                    <td><?= $jd['gender']; ?></td>
                    <td><?= $jd['phone']; ?></td>
                    <td><?= $jd['offense_id']; ?></td>
                    <td><?= $jd['date_of_offense']; ?></td>
                    <td>
                      <div class="col-12">
                        <button type="submit" class="btn btn-info btn-sm" value="<?= $jd['id']; ?>">View</a>
                      </div>
                      <div class="col-12">
                        <a href="jd-edit.php?id=<?= $jd['id']; ?>" class="btn btn-success btn-sm float-end">Edit</a>
                      </div>
                      <div class="col-12">
                        <a href="jd-delete.php?id=<?= $jd['id']; ?>" class="btn btn-danger btn-sm float-end">Delete</a>
                      </div>
                    </td>
                  </tr>
              <?php
                }
              } else {
                echo "<h5>No Record Found!</h5>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
</div>

<?php include('includes/footer.php'); ?>