<?php
session_start();
require 'connections/dbcon.php';
?>

<?php include('includes/header.php'); ?>
<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<div class="container-fluid mt-4">
  <?php include('message.php'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4>Update Juvenile Delinquent
            <a href="admin-panel.php" class="btn btn-danger float-end">BACK</a>
          </h4>
        </div>
        <div class="card-body">

          <?php
          if (isset($_GET['id'])) {
            $id = mysqli_real_escape_string($con, $_GET['id']);
            $query = "SELECT * FROM jd_tbl WHERE id = '$id' ";
            $query_run = mysqli_query($con, $query);

            if (mysqli_num_rows($query_run) > 0) {
              $jd = mysqli_fetch_array($query_run);
          ?>

              <form action="function.php" method="POST">
                <input type="hidden" name="id" value="<?= $jd['id']; ?>">
                <div class="mb-3">
                  <label>Full Name</label>
                  <input type="text" name="fullname" value="<?= $jd['fullname']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Email</label>
                  <input type="email" name="email" value="<?= $jd['email']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Address</label>
                  <input type="text" name="address" value="<?= $jd['address']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Barangay</label>
                  <input type="text" name="address" value="<?= $jd['barangay_tbl_id']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Date of Birth</label>
                  <input type="date" name="dob" value="<?= $jd['dob']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Age</label>
                  <input type="number" name="age" value="<?= $jd['age']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Gender</label>
                  <input type="text" name="gender" value="<?= $jd['gender']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Phone</label>
                  <input type="text" name="phone" value="<?= $jd['phone']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Offense</label>
                  <select type="text" class="form-select" name="offense_id" value="<?= $jd['offense_id']; ?>" class="form-control">
                    <option selected value="1">Underage Drinking</option>
                    <option value="2">Burglary</option>
                    <option value="3">Larceny</option>
                    <option value="4">Theft</option>
                    <option value="5">Arson</option>
                    <option value="6">Murder</option>
                    <option value="7">Rape</option>
                    <option value="8">Robbery</option>
                    <option value="9">Malicious Mischief</option>
                    <option value="10">Estafa</option>
                    <option value="11">Physical Injuries</option>
                    <option value="12">Illegal Gambling</option>
                    <option value="13">Attempted Murder</option>
                    <option value="14">Seduction</option>
                    <option value="15">Grave Threats</option>
                    <option value="16">Abduction</option>
                    <option value="17">Aggravated Assault</option>
                    <option value="18">Illelgal Use of Prohibited Drugs</option>
                    <option value="19">Illegal Possession of Firearms</option>
                    <option value="20">Bullying</option>
                    <option value="21">Attempted Rape</option>
                    <option value="22">Acts of Lasciviousness</option>
                    <option value="23">Drug Trafficking</option>
                  </select>
                </div>
                <div class="mb-3">
                  <label>Date of Offense</label>
                  <input type="date" name="date_of_offense" value="<?= $jd['date_of_offense']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <button type="submit" name="admin_update_jd" class="btn btn-primary">Update</button>
                </div>
              </form>

          <?php
            } else {
              echo "<h4>No such id found!</h4>";
            }
          }
          ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>