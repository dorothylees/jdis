<?php
session_start();
require 'connections/dbcon.php';
?>

<?php include('includes/header.php'); ?>
<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<div class="container-fluid mt-4">
  <?php include('message.php'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4>View User's Details
            <a href="add-user.php" class="btn btn-primary float-end">Add User</a>
          </h4>
        </div>
        <table class="table table-bordered table-striped">
          <thead>
            <tr>
              <th scope="col">ID</th>
              <th scope="col">Full Name</th>
              <th scope="col">Username</th>
              <th scope="col">Email</th>
              <th scope="col">Date of Birth</th>
              <th scope="col">Gender</th>
              <th scope="col">Address</th>
              <th scope="col" class="float-end">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $query = "SELECT * FROM users";
            $query_run = mysqli_query($con, $query);

            if (mysqli_num_rows($query_run) > 0) {
              foreach ($query_run as $user) {
            ?>
                <tr>
                  <td><?= $user['id']; ?></td>
                  <td><?= $user['fullname']; ?></td>
                  <td><?= $user['username']; ?></td>
                  <td><?= $user['email']; ?></td>
                  <td><?= $user['dob']; ?></td>
                  <td><?= $user['gender']; ?></td>
                  <td><?= $user['address']; ?></td>
                  <td class="float-end">
                    <a href="user-details.php?id=<?= $user['id']; ?>" class="btn btn-info btn-sm">View</a>
                    <a href="user-edit.php?id=<?= $user['id']; ?>" class="btn btn-success btn-sm">Edit</a>
                    <a href="user-delete.php?id=<?= $user['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                  </td>
                </tr>
            <?php
              }
            } else {
              echo "<h5>No record found!</h5>";
            }
            ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>