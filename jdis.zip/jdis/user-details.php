<?php
session_start();
require 'connections/dbcon.php';
?>
<?php include('includes/header.php'); ?>
<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<div class="container-fluid mt-4">
  <div class="row">
    <div class="col">
      <div class="card">
        <div class="card-header">
          <h4>View User's Details
            <a href="add-user.php" class="btn btn-primary float-end">Add User</a>
          </h4>
        </div>
        <div class="card-body">
          <?php
          if (isset($_GET['id'])) {
            $id = mysqli_real_escape_string($con, $_GET['id']);
            $query = "SELECT * FROM users WHERE id = '$id' ";
            $query_run = mysqli_query($con, $query);

            if (mysqli_num_rows($query_run) > 0) {
              $user = mysqli_fetch_array($query_run);
          ?>
              <div class="mb-3">
                <label>ID</label>
                <p class="form-control">
                  <?= $user['id']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Full Name</label>
                <p class="form-control">
                  <?= $user['fullname']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Username</label>
                <p class="form-control">
                  <?= $user['username']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Email</label>
                <p class="form-control">
                  <?= $user['email']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Password</label>
                <p class="form-control">
                  <?= $user['password']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Date of Birth</label>
                <p class="form-control">
                  <?= $user['dob']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Age</label>
                <p class="form-control">
                  <?= $user['age']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Gender</label>
                <p class="form-control">
                  <?= $user['gender']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Address</label>
                <p class="form-control">
                  <?= $user['address']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Barangay ID</label>
                <p class="form-control">
                  <?= $user['barangay_tbl_id']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Mobile</label>
                <p class="form-control">
                  <?= $user['mobile']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Position</label>
                <p class="form-control">
                  <?= $user['position']; ?>
                </p>
              </div>
              <div class="mb-3">
                <label>Date Added</label>
                <p class="form-control">
                  <?= $user['date_added']; ?>
                </p>
              </div>
          <?php
            } else {
              echo "<h4>No such id found!</h4>";
            }
          }
          ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>