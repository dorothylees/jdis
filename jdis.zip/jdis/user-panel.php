<?php
session_start();
require 'connections/dbcon.php';
?>

<?php include('includes/header.php'); ?>

<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<div class="container-fluid">
  <?php include('message.php'); ?>
  <div class="row">
    <div class="col-md-3">
      <div class="list-group">
        <a href="" class="list-group-item active p-3 mt-4">Dashboard</a>
        <a href="user_add_jd.php" class="list-group-item">Add Juvenile Delinquent</a>
        <a href="user_view_jd.php" class="list-group-item">View Juvenile Delinquent</a>
        <a href="user_search_jd.php" class="list-group-item">Search Juvenile Delinquent</a>
      </div>
    </div>

    <div class="col-md-8 mt-4">
      <div class="card">

        <div class="card-body p-3 mb-2 bg-primary text-white list-group-item active">
          <h5>Add Juvenile Delinquent</h5>
        </div>
        <div class="card-body"></div>
        <form class="form-control" action="function.php" method="post">
          <label>Full Name:</label>
          <input type="text" name="fullname" class="form-control"><br>
          <label>Email:</label>
          <input type="email" name="email" class="form-control"><br>
          <label>Address:</label>
          <input type="text" name="address" class="form-control"><br>
          <label>Barangay</label>
          <select class="form-select form-control" name="barangay_tbl_id">
            <option selected value="1">Alegria</option>
            <option value="2">Bagong Silang</option>
            <option value="3">Biasong</option>
            <option value="4">Bonifacio</option>
            <option value="5">Burgos</option>
            <option value="6">Dalacon</option>
            <option value="7">Dampalan</option>
            <option value="8">Don Andres Soriano</option>
            <option value="9">Eastern Poblacion</option>
            <option value="10">Estante</option>
            <option value="11">Hasaan</option>
            <option value="12">Katipa</option>
            <option value="13">Luzaran</option>
            <option value="14">Mabas</option>
            <option value="15">Macalibre Alto</option>
            <option value="16">Macalibre Bajo</option>
            <option value="17">Mahayahay</option>
            <option value="18">Manguehan</option>
            <option value="19">Mansabay Alto</option>
            <option value="20">Mansabay Bajo</option>
            <option value="21">Molatuhan Alto</option>
            <option value="22">Molatuhan Bajo</option>
            <option value="23">Peniel</option>
            <option value="24">Puntod</option>
            <option value="25">Rizal</option>
            <option value="26">Sibugon</option>
            <option value="27">Sibula</option>
            <option value="28">Western Poblacion</option>
          </select><br>
          <label>Date of Birth:</label>
          <input type="date" name="dob" class="form-control"><br>
          <label>Age:</label>
          <input type="text" name="age" class="form-control"><br>
          <label>Gender:</label>
          <input type="text" name="gender" class="form-control"><br>
          <label>Phone:</label>
          <input type="text" name="phone" class="form-control"><br>
          <label>Offense</label>
          <select class="form-select" name="offense_id">
            <option selected value="1">Underage Drinking</option>
            <option value="2">Burglary</option>
            <option value="3">Larceny</option>
            <option value="4">Theft</option>
            <option value="5">Arson</option>
            <option value="6">Murder</option>
            <option value="7">Rape</option>
            <option value="8">Robbery</option>
            <option value="9">Malicious Mischief</option>
            <option value="10">Estafa</option>
            <option value="11">Physical Injury</option>
            <option value="12">Illegal Gambling</option>
            <option value="13">Attempted Murder</option>
            <option value="14">Seduction</option>
            <option value="15">Grave Threats</option>
            <option value="16">Abduction</option>
            <option value="17">Aggravated Assault</option>
            <option value="18">Illegal Use of Prohibited Drugs</option>
            <option value="19">Illegal Position of Firearms</option>
            <option value="20">Bullying</option>
            <option value="21">Attempted Rape</option>
            <option value="22">Acts of Lasciviousness</option>
            <option value="23">Drug Trafficking</option>
          </select><br>
          <label>Date Of Offense</label>
          <input type="date" name="date_of_offense" class="form-control"><br>
          <input type="submit" class="btn btn-primary" name="user_jd_submit" value="Register"> <a href="function.php" class="btn btn-light"></a>

        </form>
      </div>
    </div>
  </div>
  <div class="col-md-1"></div>
</div>
</div>
</div>
<header>
  <nav>
    <div class="main-wrapper">

      <div class="nav-login">
        <?php
        if (isset($_SESSION['id'])) {
          echo '<form action="includes/index.php" method="POST">
					            <button type="submit" name="submit">logout</button>
					              </form>';
        } else {

          echo '<form action="includes/index.php" method="POST">
                              
                               						
				                </form>
				              <a href="index.php" class="btn btn-light" style="background-color:#4169e1;color:FFFFFF;">Logout</a>';
        }

        ?>


      </div>
    </div>
  </nav>

</header>

<?php include('includes/footer.php'); ?>