<?php
session_start();
include 'connections/dbcon.php';

if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['role'])) {
  function test_input($data)
  {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
  $username = test_input($_POST['username']);
  $username = ucwords($username);
  $password = test_input($_POST['password']);
  $role = test_input($_POST['role']);

  if (empty($username)) {
    header("Location: index.php?error=Username is Required");
  } elseif (empty($password)) {
    header("Location: index.php?error=Password is required");
  } else {
    $password = md5($password);

    $sql = "SELECT * FROM users where username = '$username' AND password = '$password'";
    $result = mysqli_query($con, $sql);

    if ($mysqli_num_rows($result) === 1) {
      $row = mysqli_fetch_assoc($result);
      if ($row['password'] === $password && $row['role'] == $role) {
        $_SESSION['fullname'] = $row['fullname'];
        $_SESSION['id'] = $row['id'];
        $_SESSION['role'] = $row['role'];
        $_SESSION['username'] = $row['username'];

        header("Location: admin-panel.php");
      } else {
        header("Location: index.php?error=Incomplete username or password");
      }
    } else {
      header("Location: index.php?error=Incomplete username or password");
    }
  }
} else {
  header("Location: index.php");
}



function login()
{
  $con = dbConnect();
  $username = $_POST['username'];
  $password = $_POST['password'];
  $error = "<div class ='alert alert-danger text-center fw-bold' role='alert'>Incorrect Username or Password</div>";

  $sql = "SELECT * FROM users WHERE username = '$username'";

  if ($result = $con->query($sql)) {
    if ($result->num_rows == 1) {
      $user_details = $result->fetch_assoc();
      if (password_verify($password, $user_details['password'])) {
        session_start();
        $_SESSION['id'] = $user_details['id'];
        $_SESSION['role'] = $user_details['role'];
        $_SESSION['fullname'] = $user_details['fullname'];

        if ($user_details['role'] == 'admin') {
          header("Location: admin-panel.php");
        } elseif ($user_details['role'] == 'user') {
          header("Location: user-panel.php");
        }
        exit;
      } else {
        echo $error;
      }
    } else {
      echo $error;
    }
  } else {
    die("Error: " . $con->error);
  }
}

if (isset($_POST['admin_user_submit'])) {

  $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
  $username = mysqli_real_escape_string($con, $_POST['username']);
  $email = mysqli_real_escape_string($con, $_POST['email']);
  $password = mysqli_real_escape_string($con, $_POST['password']);
  $dob = mysqli_real_escape_string($con, $_POST['dob']);
  $age = mysqli_real_escape_string($con, $_POST['age']);
  $gender = mysqli_real_escape_string($con, $_POST['gender']);
  $address = mysqli_real_escape_string($con, $_POST['address']);
  $barangay_tbl_id = mysqli_real_escape_string($con, $_POST['barangay_tbl_id']);
  $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
  $position = mysqli_real_escape_string($con, $_POST['position']);
  $role = mysqli_real_escape_string($con, $_POST['role']);

  $query = $con->query("SELECT * FROM users WHERE username = '$username'") or die(mysqli_error());

  $query_run = mysqli_query($con, $query);
  $f1 = $query->fetch_array();
  $result = $query->num_rows;
  if ($result > 0) {
    echo "<script>alert('Username already taken')</script>";
  } else {
    $con->query("INSERT INTO users (`fullname`, `username`, `email`, `password`, `dob`, `age`, `gender`, `address`, `barangay_tbl_id`, `mobile`, `position`, `role`) VALUES ('$fullname', '$username', '$email', '" . md5($password) . "', '$dob', '$age', '$gender',  '$address', '$barangay_tbl_id', '$mobile','$position', '$role'");
  }
}


if (isset($_POST['admin_jd_submit'])) {

  $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
  $email = mysqli_real_escape_string($con, $_POST['email']);
  $address = mysqli_real_escape_string($con, $_POST['address']);
  $barangay_tbl_id = mysqli_real_escape_string($con, $_POST['barangay_tbl_id']);
  $dob = mysqli_real_escape_string($con, $_POST['dob']);
  $age = mysqli_real_escape_string($con, $_POST['age']);
  $gender = mysqli_real_escape_string($con, $_POST['gender']);
  $phone = mysqli_real_escape_string($con, $_POST['phone']);
  $offense_id = mysqli_real_escape_string($con, $_POST['offense_id']);
  $date_of_offense = mysqli_real_escape_string($con, $_POST['date_of_offense']);

  $query = "INSERT INTO jd_tbl (fullname, email, address, barangay_tbl_id, dob, age, gender, phone, offense_id, date_of_offense) VALUES ('$fullname','$email','$address', '$barangay_tbl_id', '$dob', '$age', '$gender', '$phone','$offense_id', '$date_of_offense')";

  $query_run = mysqli_query($con, $query);
  if ($query_run) {
    $_SESSION['message'] = "Juvenile Delinquent Added Successfully!";
    header("Location: admin-panel.php");
    exit(0);
  } else {
    echo "<script>alert('Juvenile Delinquent Not Added!')</script>";
    echo "<script>window.open('admin-panel.php','_self')</script>";
    exit(0);
  }
}

if (isset($_POST['admin_update_user'])) {
  $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
  $username = mysqli_real_escape_string($con, $_POST['username']);
  $email = mysqli_real_escape_string($con, $_POST['email']);
  $password = mysqli_real_escape_string($con, $_POST['password']);
  $dob = mysqli_real_escape_string($con, $_POST['dob']);
  $age = mysqli_real_escape_string($con, $_POST['age']);
  $gender = mysqli_real_escape_string($con, $_POST['gender']);
  $address = mysqli_real_escape_string($con, $_POST['address']);
  $barangay_tbl_id = mysqli_real_escape_string($con, $_POST['barangay_tbl_id']);
  $mobile = mysqli_real_escape_string($con, $_POST['mobile']);
  $position = mysqli_real_escape_string($con, $_POST['position']);
  $role = mysqli_real_escape_string($con, $_POST['role']);

  $query = "UPDATE users SET fullname = '$fullname', username = '$username', email = '$email', password = '$password', dob = '$dob', age = '$age', gender = '$gender', address = '$address', barangay_tbl_id = '$barangay_tbl_id', mobile = $mobile, position = '$position', role = '$role' WHERE id = '$id'";

  $query = "INSERT INTO users (fullname, username, email, password,  dob, age, gender, address, barangay_tbl_id, mobile, position, role) VALUES ('$fullname', '$username','$email', '$password', '$dob', '$age', '$gender', '$address', '$barangay_tbl_id', $mobile, '$position', '$role')";

  $query_run = mysqli_query($con, $query);

  if ($query_run) {
    $_SESSION['message'] = "User Updated Successfully!";
    header("Location: admin-panel.php");
    exit(0);
  } else {
    $_SESSION['message'] = "User Not Updated!";
    header("Location: admin-panel.php");
    exit(0);
  }
}

if (isset($_POST['admin_update_jd'])) {
  $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
  $email = mysqli_real_escape_string($con, $_POST['email']);
  $address = mysqli_real_escape_string($con, $_POST['address']);
  $barangay_tbl_id = mysqli_real_escape_string($con, $_POST['barangay_tbl_id']);
  $dob = mysqli_real_escape_string($con, $_POST['dob']);
  $age = mysqli_real_escape_string($con, $_POST['age']);
  $gender = mysqli_real_escape_string($con, $_POST['gender']);
  $phone = mysqli_real_escape_string($con, $_POST['phone']);
  $offense_id = mysqli_real_escape_string($con, $_POST['offense_id']);
  $date_of_offense = mysqli_real_escape_string($con, $_POST['date_of_offense']);

  $query = "UPDATE students SET fullname = '$fullname', email = '$email', address = '$address', barangay_tbl_id = '$barangay_tbl_id', dob = '$dob', age = '$age', gender = '$gender', phone = '$phone', offense_id = '$offense_id', date_of_offense = '$date_of_offense' WHERE id = '$id'";
  $query_run = mysqli_query($con, $query);

  if ($query_run) {
    $_SESSION['message'] = "Juvenile Delinquent Updated Successfully!";
    header("Location: admin-panel.php");
    exit(0);
  } else {
    $_SESSION['message'] = "Juvenile Delinquent Not Updated!";
    header("Location: index.php");
    exit(0);
  }
}

if (isset($_POST['user_update_jd'])) {
  $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
  $email = mysqli_real_escape_string($con, $_POST['email']);
  $address = mysqli_real_escape_string($con, $_POST['address']);
  $barangay_tbl_id = mysqli_real_escape_string($con, $_POST['barangay_tbl_id']);
  $dob = mysqli_real_escape_string($con, $_POST['dob']);
  $age = mysqli_real_escape_string($con, $_POST['age']);
  $gender = mysqli_real_escape_string($con, $_POST['gender']);
  $phone = mysqli_real_escape_string($con, $_POST['phone']);
  $offense_id = mysqli_real_escape_string($con, $_POST['offense_id']);
  $date_of_offense = mysqli_real_escape_string($con, $_POST['date_of_offense']);

  $query = "UPDATE jd_tbl SET fullname = '$fullname', email = '$email', address = '$address', barangay_tbl_id = '$barangay_tbl_id', dob = '$dob', age = '$age', gender = '$gender', phone = '$phone', offense_id = '$offense_id', date_of_offense = '$date_of_offense' WHERE id = '$id'";
  $query_run = mysqli_query($con, $query);

  if ($query_run) {
    $_SESSION['message'] = "Juvenile Delinquent Updated Successfully!";
    header("Location: user-panel.php");
    exit(0);
  } else {
    $_SESSION['message'] = "Juvenile Delinquent Not Updated!";
    header("Location: user_panel.php");
    exit(0);
  }
}

if (isset($_POST['admin_delete_user'])) {
  $id = mysqli_real_escape_string($con, $_POST['admin_delete_user']);

  $query = "DELETE FROM users WHERE id = '$id'";
  $query_run = mysqli_query($con, $query);

  if ($query_run) {
    $_SESSION['message'] = "User Deleted Successfully!";
    header("Location: view-user.php");
    exit(0);
  } else {
    $_SESSION['message'] = "User Not Deleted!";
    header("Location: view-user.php");
    exit(0);
  }
}

if (isset($_POST['delete-jd'])) {
  $id = mysqli_real_escape_string($con, $_POST['delete-jd']);

  $query = "DELETE FROM jd_tbl WHERE id = '$id'";
  $query_run = mysqli_query($con, $query);

  if ($query_run) {
    $_SESSION['message'] = "Juvenile Delinquent Deleted Successfully!";
    header("Location: view-jd.php");
    exit(0);
  } else {
    $_SESSION['message'] = "Juvenile Delinquent Not Deleted!";
    header("Location: view-jd.php");
    exit(0);
  }
}

if (isset($_POST['user_delete_jd'])) {
  $id = mysqli_real_escape_string($con, $_POST['user_delete_jd']);

  $query = "DELETE FROM jd_tbl WHERE id = '$id'";
  $query_run = mysqli_query($con, $query);

  if ($query_run) {
    $_SESSION['message'] = "Juvenile Delinquent Deleted Successfully!";
    header("Location: user_view_jd.php");
    exit(0);
  } else {
    $_SESSION['message'] = "Juvenile Delinquent Not Deleted!";
    header("Location: user_view_jd.php");
    exit(0);
  }
}

if (isset($_POST['user_jd_submit'])) {

  $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
  $email = mysqli_real_escape_string($con, $_POST['email']);
  $address = mysqli_real_escape_string($con, $_POST['address']);
  $barangay_tbl_id = mysqli_real_escape_string($con, $_POST['barangay_tbl_id']);
  $dob = mysqli_real_escape_string($con, $_POST['dob']);
  $age = mysqli_real_escape_string($con, $_POST['age']);
  $gender = mysqli_real_escape_string($con, $_POST['gender']);
  $phone = mysqli_real_escape_string($con, $_POST['phone']);
  $offense_id = mysqli_real_escape_string($con, $_POST['offense_id']);
  $date_of_offense = mysqli_real_escape_string($con, $_POST['date_of_offense']);

  $query = "UPDATE SET `jd_tbl` `fullname`='$fullname',`email`='$email', `address`='$address',`barangay_tbl_id`='$barangay_tbl_id',`dob`='$dob', `age`='$age',`gender`='$gender',`phone`='$phone',`offense_id`='$offense_id',`date_of_offense`='$date_of_offense' WHERE id = '$id'";

  $query = "INSERT INTO `jd_tbl`(`fullname`, `email`, `address`,`barangay_tbl_id`,`dob`, `age`, `gender`, `phone`, `offense_id`, `date_of_offense`) VALUES ('$fullname', '$email', '$address','$barangay_tbl_id','$dob', '$age','$gender', '$phone', '$offense_id',  '$date_of_offense')";

  $query_run = mysqli_query($con, $query);
  if ($query_run) {
    $_SESSION['message'] = "Juvenile Delinquent Added Successfully!";
    header("Location: user-panel.php");
    exit(0);
  } else {
    $_SESSION['message'] = "Juvenile Delinquent Not Added!";
    header("Location: user-panel.php");
    exit(0);
  }
}

function displayAllJuvenileDelinquents()
{
  $con = dbConnect();
  $sql = "SELECT id, fullname, email, address, barangay_tbl_id, dob, age, gender, phone, offense_id, date_of_offense FROM jd_tbl INNER JOIN barangay_tbl ON jd_tbl.barangay_tbl__id = barangay_tbl.id INNER JOIN users ON jd_tbl.barangay_tbl_id = users.barangay_tbl_id ORDER BY date_of_offense";

  if ($result = $con->query($sql)) {
    if ($result->num_rows > 0) {
      while ($jd = mysqli_fetch_array($result)) {
        $id = $jd['id'];
        $fullname = $jd['fullname'];
        $email = $jd['email'];
        $address = $jd['address'];
        $barangay_tbl_id = $jd['barangay_tbl_id'];
        $dob = $jd['dob'];
        $age = $jd['age'];
        $gender = $jd['gender'];
        $phone = $jd['phone'];
        $offense_id = $jd['offense_id'];
        $date_of_offense = $jd['date_of_offense'];

        echo "
                    <tr>
                        <td>" . $jd['id'] . "</td>
                        <td>" . $jd['fullname'] . "</td>
                        <td>" . $jd['email'] . "</td>
                        <td>" . $jd['address'] . "</td>
                        <td>" . $jd['barangay_tbl_id'] . "</td>
                        <td>" . $jd['dob'] . "</td>
                        <td>" . $jd['age'] . "</td>
                        <td>" . $jd['gender'] . "</td>
                        <td>" . $jd['phone'] . "</td>
                        <td>" . $jd['offense_id'] . "</td>
                        <td>" . date("M d, Y", strtotime($jd['date_of_offense'])) . "</td>
                        <td>
                            <a href='jd-details.php?id=" . $jd['id'] . "' class='btn btn-sm btn-outline-dark'><i class='fas fa-angle-double-right'></i> Juvenile Delinquent Details</a>
                        </td>
                    </tr>
                ";
      }
    } else {
      echo "<tr>
                <td colspan='5' class='text-center lead fst-italic fw-bold'>
                    No Records Found
                </td>
            </tr>";
    }
  } else {
    die("Error: " . $con->error);
  }
}

function countJuvenileDelinquents($id)
{
  $con = dbConnect();
  $sql = "SELECT COUNT(id) AS juveniledelinquent_count FROM jd_tbl WHERE id = $id";

  if ($result = $con->query($sql)) {
    $result_assoc = $result->fetch_assoc();
    return $result_assoc['juveniledelinquent_count'];
  } else {
    die("Error: " . $con->error);
  }
}
