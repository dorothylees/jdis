<?php
session_start();
require 'connections/dbcon.php';
?>

<?php include('includes/header.php'); ?>

<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<?php include('message.php'); ?>
<div class="container mt-4">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4>View Juvenile Delinquents
            <a href="user-panel.php" class="btn btn-primary float-end">Add JD</a>
          </h4>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Barangay</th>
                <th>Date of Birth</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Phone</th>
                <th>Offense</th>
                <th>Date of Offense</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php
              displayAllJuvenileDelinquents();
              ?>
            </tbody>
          </table>
        </div>
        <nav class="col-3"></nav>
        <div class="card bg-primary mb-4 border-5">
          <div class="card-body text-center text-white">
            <h3>View Juvenile Delinquents</h3>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php include('includes/footer.php'); ?>