<?php
session_start();
require 'connections/dbcon.php';
?>

<?php include('includes/header.php'); ?>
<div class="jumbotron" style="background: url('img/lopez jaenabanner.jpg') no-repeat;background-size: cover;height: 400px;"></div>
<div class="container-fluid mt-4">
  <?php include('message.php'); ?>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4>Update User
            <a href="index.php" class="btn btn-danger float-end">BACK</a>
          </h4>
        </div>
        <div class="card-body">

          <?php
          if (isset($_GET['id'])) {
            $id = mysqli_real_escape_string($con, $_GET['id']);
            $query = "SELECT * FROM users WHERE id = '$id' ";
            $query_run = mysqli_query($con, $query);

            if (mysqli_num_rows($query_run) > 0) {
              $user = mysqli_fetch_array($query_run);
          ?>

              <form action="function.php" method="POST">
                <input type="hidden" name="id" value="<?= $user['id']; ?>">
                <div class="mb-3">
                  <label>Full Name</label>
                  <input type="text" name="fullname" value="<?= $user['fullname']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Username</label>
                  <input type="text" name="username" value="<?= $user['username']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Email</label>
                  <input type="email" name="email" value="<?= $user['email']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Password</label>
                  <input type="password" name="password" value="<?= $user['password']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Date of Birth</label>
                  <input type="date" name="dob" value="<?= $user['dob']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Age</label>
                  <input type="text" name="age" value="<?= $user['age']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Gender</label>
                  <input type="text" name="gender" value="<?= $user['gender']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Address</label>
                  <input type="text" name="address" value="<?= $user['address']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Barangay</label>
                  <input type="text" name="barangay_tbl_id" value="<?= $user['barangay_tbl_id']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Mobile</label>
                  <input type="text" name="mobile" value="<?= $user['mobile']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <label>Position</label>
                  <input type="text" name="position" value="<?= $user['position']; ?>" class="form-control">
                </div>
                <div class="mb-3">
                  <button type="submit" name="admin_update_user" class="btn btn-primary form-control float-end">Update User</button>
                </div>
              </form>

          <?php
            } else {
              echo "<h4>No such id found!</h4>";
            }
          }
          ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include('includes/footer.php'); ?>